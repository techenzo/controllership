<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblVendor extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_vendors_info', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('first_name');
            $table->string('last_name');
            $table->string('address');
            $table->string('email')->unique();
            $table->string('web_url');
            $table->string('contract');
            $table->string('category');
            $table->string('department');
            $table->timestamp('effectivedate');
            $table->timestamp('effectivedate');
            $table->unsignedInteger('status_id');
            $table->unsignedInteger('user_id');
            $table->longText('termination');
            $table->longText('payment');
            $table->longText('spend');
            $table->longText('penalty');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_vendors_info');
    }
}
